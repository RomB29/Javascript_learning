// Etape 1 - Sélectionner nos éléments

// Etape 2 - Cacher l'erreur

// Etape 3 - Générer un nombre aléatoire

// Etape 4 - Vérifier que l'utilisateur donne bien un nombre

// Etape 5 - Agir à l'envoi du formulaire

// Etape 6 - Créer la fonction vérifier